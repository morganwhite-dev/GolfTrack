Roundly Xcode App Icon Set

How to use:
1. Unzip this file.
2. In Xcode, open Assets.xcassets.
3. Replace your existing AppIcon.appiconset with the included AppIcon.appiconset folder, or drag the PNGs into the matching AppIcon slots.
4. The set includes iPhone, iPad, and iOS marketing 1024x1024 icons.

Note: This icon image includes rounded-corner styling as part of the artwork because that was the selected visual direction. iOS will also apply its own mask at runtime.
