# Roundly App Icon PNGs

Generated standalone app icon exports for Roundly.

Included pixel sizes:

- 20x20
- 29x29
- 40x40
- 58x58
- 60x60
- 76x76
- 80x80
- 87x87
- 120x120
- 152x152
- 167x167
- 180x180
- 1024x1024

Use `../RoundlyAppIcon.appiconset` as the drop-in Xcode asset catalog version.
